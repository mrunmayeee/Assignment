package com.cg2.eis.pl;


import java.util.Scanner;

import com.cg2.eis.service.EmployeeInsuranceSystem;
import com.cg2.eis.service.EmployeeService;
import com.cg2.eis.bean.Employee;

public class InvokeFunction {

	public static void main(String[] args) {
		
		
		Employee emp = new Employee();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter id: ");
		emp.setId(sc.nextInt());

		System.out.println("Enter name: ");
		emp.setName(sc.next());

		System.out.println("Enter salary: ");
		emp.setSalary(sc.nextInt());

		System.out
				.println("Enter designation as System Associate,Programmer,Manager,Clerk: ");
		emp.setDesignation(sc.next());

		EmployeeService es = new EmployeeInsuranceSystem();

		es.getDetails(emp);
		es.insuranceScheme(emp);
		es.displayDetails(emp);
		
		System.out.println("Enter Scheme: ");
		sc=new Scanner(System.in);
		String insurance=sc.nextLine();
		es.display(emp,insurance);
		
		sc.close();
		
		

	}

}
