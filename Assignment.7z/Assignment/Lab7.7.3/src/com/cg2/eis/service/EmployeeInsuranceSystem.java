package com.cg2.eis.service;

import java.util.HashMap;

import com.cg2.eis.bean.Employee;
import com.cg2.eis.service.EmployeeService;

public class EmployeeInsuranceSystem implements EmployeeService{

	
	HashMap<Integer,Employee> list = new HashMap<Integer,Employee>();
	
	
	
	//Employee emp = new Employee();
	 

	public void getDetails(Employee emp) {
          insuranceScheme(emp);
		list.put(emp.getId(), emp);
	}

	
	
	public void insuranceScheme(Employee emp) {
		int salary=emp.getSalary();
		String designation=emp.getDesignation();
		String insuranceScheme=null;
		if (((salary > 5000) && (salary < 20000))
				&& (("System Associate".equals(designation)))) {
			insuranceScheme="Scheme C";

		}

		else if (((salary >= 20000) && (salary < 40000))
				&& (("Programmer".equals(designation)))) {
			insuranceScheme="Scheme B";
		} else if (((salary >= 40000)) && (("Manager".equals(designation)))) {
			insuranceScheme="Scheme A";
		} else if (((emp.getSalary() < 5000))
				&& (("Clerk".equals(emp.getDesignation())))) {
			insuranceScheme="No Scheme";
		}
		emp.setInsuranceScheme(insuranceScheme);

	}

	public void delete(Employee emp){
		list.remove(emp);
	}
	
	public void displayDetails(Employee emp) {
		
		
		
		System.out.println(list);
		
		
	}
	
	public void display(Employee emp,String insurance){
		System.out.println(emp.getInsuranceScheme());
		System.out.println(insurance);
		if(insurance.equals(emp.getInsuranceScheme())){
			System.out.println(list);
		}
		else{
			System.out.println("Invalid");
		}
	}

}
