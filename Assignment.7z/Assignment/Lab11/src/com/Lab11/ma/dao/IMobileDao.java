package com.Lab11.ma.dao;

import java.util.List;

import com.Lab11.ma.dto.Mobile;
import com.Lab11.ma.exception.MobileException;

public interface IMobileDao {

	List<Mobile> showAll() throws MobileException;
	boolean deleteMobile(int mobileId) throws MobileException;
	List<Mobile> searchByRange(int start,int end) throws MobileException;
	boolean updateQty(int mobileId,int quantity) throws MobileException;
}
