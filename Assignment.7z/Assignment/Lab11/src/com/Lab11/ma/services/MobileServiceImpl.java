package com.Lab11.ma.services;

import java.util.List;

import com.Lab11.ma.dao.IMobileDao;
import com.Lab11.ma.dao.MobileDaoImpl;
import com.Lab11.ma.dto.Mobile;
import com.Lab11.ma.exception.MobileException;

public class MobileServiceImpl implements IMobileService{
	IMobileDao imd = new MobileDaoImpl();

	public List<Mobile> showAllMobiles() throws MobileException {
		// TODO Auto-generated method stub
		return imd.showAll();
	}

	public boolean deleteMobile(int mobileId) throws MobileException {
		// TODO Auto-generated method stub
		return imd.deleteMobile(mobileId);
	}

	public List<Mobile> searchMobile(int start, int end) throws MobileException {
		// TODO Auto-generated method stub
		return imd.searchByRange(start, end);
	}
	/*public boolean updateQuantity(String mobileId, int quantity) throws MobileException{
		return imd.updateQty(mobileId, quantity);
	}*/

	public boolean updateQty(int mobileId, int quantity)
			throws MobileException {
		return imd.updateQty(mobileId, quantity);
		// TODO Auto-generated method stub
		
	}
	

}
