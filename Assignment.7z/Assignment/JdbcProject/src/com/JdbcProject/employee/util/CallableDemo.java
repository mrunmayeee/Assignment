package com.JdbcProject.employee.util;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class CallableDemo {

	public static void main(String[] args) {

		Connection con = null;
		CallableStatement cs = null;
		String query = "{call getSalary(?,?)}";
		con = JdbcUtil.getConnection();
		try {
			cs = con.prepareCall(query);
			cs.setInt(1, 105); //employee code is 105
			cs.registerOutParameter(2, java.sql.Types.INTEGER);//need to register out parameter
			cs.execute();
			int salary = cs.getInt(2); //returns salary for employee code 105
			System.out.println(salary);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
