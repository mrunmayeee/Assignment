package com.Mrunmayi.Assignment4.Assign42;

public class SavingAccount extends Account {
	int balance=2000;
public final int  minBal=500;

public int getMinBalance(){
	return minBal;
}

	public boolean withdraw(int amount){
		balance=balance-amount;
		if(balance<=minBal){
			return false;
		}
		else{
		return true;
		}
	}
}
