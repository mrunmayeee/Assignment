package com.Mrunmayi.Assignment3;

import java.util.Scanner;

public class TestPositive {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a string: ");
		String str = sc.next();
		PositiveString ps = new PositiveString();
		ps.checkPositive(str);
		sc.close();

	}

}
