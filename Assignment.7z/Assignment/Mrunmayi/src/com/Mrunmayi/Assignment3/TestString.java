package com.Mrunmayi.Assignment3;

import java.util.Scanner;

public class TestString {

	public static void main(String[] args) {
		
		String str;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter a string :");
		
		str = sc.next();
		
		StringUtil.addString(str);
		StringUtil.replaceString(str);
		StringUtil.removeDuplicate(str);
		StringUtil.upperCaseString(str);
	}

}
