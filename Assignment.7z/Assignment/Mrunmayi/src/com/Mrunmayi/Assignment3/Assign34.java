package com.Mrunmayi.Assignment3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Assign34 {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the first date in this format 'yyyy-MM-dd'");
		String date1=sc.next();
		
		System.out.println("Enter the second date in this format 'yyyy-MM-dd'");
		String date2=sc.next();
		
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
				
		LocalDate givenDate1=LocalDate.parse(date1,formatter);
		LocalDate givenDate2=LocalDate.parse(date2,formatter);
		LocalDate currentDate=LocalDate.now();
		Period period=givenDate1.until(givenDate2);
		System.out.println("Today"+currentDate);
	
		/*System.out.println("Days "+period.get(ChronoUnit.DAYS));
		System.out.println("Months "+period.get(ChronoUnit.MONTHS));
		System.out.println("Years "+period.get(ChronoUnit.YEARS));*/

		System.out.println("Days "+period.getDays());
		System.out.println("Months "+period.getMonths());
		System.out.println("Years "+period.getYears());
	
	}

}
