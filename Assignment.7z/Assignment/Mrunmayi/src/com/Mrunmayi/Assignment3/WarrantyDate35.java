package com.Mrunmayi.Assignment3;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class WarrantyDate35 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the date in this format 'yyyy-MM-dd'");
		String date=sc.next();
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate date2=LocalDate.parse(date,formatter);
        System.out.println("Enter warantee period in months and years");
        int waranteeMonths=sc.nextInt();
        int waranteeYears=sc.nextInt();
        
       date2=date2.plusMonths(waranteeMonths);
        System.out.println("Warantee Date is "+date2.plusYears(waranteeYears));
	}
}
