package com.Mrunmayi.Assignment3;

public class StringUtil {

	public static void addString(String str) {
		String res;

		res = str.concat(str);

		System.out.println("Concated String to itself---> " + res);
	}

	public static void replaceString(String str) {

		char arr[] = str.toCharArray();
		int len = str.length();
		char a[] = new char[len];
		int i = 0;

		while (i < arr.length) {
			if (i % 2 == 0) {
				a[i] = arr[i];
			} else if (i % 2 != 0) {
				a[i] = '#';
			}
			i++;
		}
		System.out.println("Replaced String--->");
		for (int j = 0; j < len; j++) {
			System.out.print(a[j]);
		}
		System.out.println();
	}

	public static void removeDuplicate(String str) {
		String s = str;
		for (int i = 0; i < str.length(); i++) {
			for (int j = 1; j < str.length(); j++) {
				if (i == j) {
					continue;
				} else if (str.charAt(i) == str.charAt(j)) {
					s = s.replace((str.charAt(i)), ' ');
				}
			}

		}
		System.out.println("Duplicate removed--->" + s);
	}

	public static void upperCaseString(String str) {

		char arr[] = str.toCharArray();
		int len = str.length();
		char a[] = new char[len];
		int i = 0;

		while (i < arr.length) {
			if (i % 2 == 0) {
				a[i] = arr[i];
			} else if (i % 2 != 0) {
				char m = arr[i];
				a[i] = Character.toUpperCase(m);
			}
			i++;
		}
		System.out.println("Uppercase--->");
		for (int j = 0; j < len; j++) {
			System.out.print(a[j]);
		}
	}

}
