package com.Mrunmayi.Assignment8;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

public class ReverseFile81 {

	public static void main(String[] args) {
		 FileReader fr;
		 String data=null;
		try {
			fr = new FileReader("d:\\words.txt");
			 BufferedReader fw = new BufferedReader(fr);
	          data = fw.readLine();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        


             StringTokenizer tokens = new StringTokenizer(data, " .,\"-");
             while (tokens.hasMoreTokens()){
                             String ss = tokens.nextToken();
                             for (int i = ss.length() - 1; i>=0; i--) {

                             char dd = ss.charAt(i);
                             System.out.print(dd);
                             }
                             System.out.print(" ");


                 }

	}
}
