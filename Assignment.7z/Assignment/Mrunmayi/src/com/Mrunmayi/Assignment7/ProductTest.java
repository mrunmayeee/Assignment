package com.Mrunmayi.Assignment7;

import java.util.Arrays;
import java.util.Scanner;



public class ProductTest {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("No of product:");
		int len = sc.nextInt();
		String arr[]=new String[len];
		
		System.out.println("Enter "+len+" products-->");
		
		for(int i=0;i<len;i++){
			arr[i]=sc.nextLine();
		}
		
		System.out.println("Original list-->");
		for(int i=0;i<len;i++){
			System.out.println(arr[i]);
		}
		
		System.out.println("Sorted List-->");
		Arrays.sort(arr);
		for(String s:arr){
			System.out.println(s);
		}
	}

}
