package com.Mrunmayi.Assignment6.Assign61;

public class NameException extends Exception {


	
	NameException(String msg ){
		super(msg);
		
	}

	
}
