package com.Mrunmayi.Assignment6.Assign61;

import java.util.Scanner;

public class PersonMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String fName,lName;
		String gender;
		System.out.println("Enter First Name: ");
		fName=sc.nextLine();
		System.out.println("Enter Last Name: ");
		lName=sc.nextLine();
		System.out.println("Enter Gender: ");
		gender=sc.nextLine();
		Person p = new Person(fName,lName,gender);
		try {
			p.display();
		} catch (NameException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
