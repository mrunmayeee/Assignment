package com.Mrunmayi.Assignment6.Assign61;

public class Person {

	String fName,lName, gender;
	public Person(String fName, String lName, String gender) {
		super();
		this.fName = fName;
		this.lName = lName;
		this.gender = gender;
	}
	
	public void display() throws NameException{
		if(fName.length()==0){
			throw new NameException(" First name should not be empty");
		}
		else if(lName.length()==0){
			throw new NameException(" Last name should not be empty");
		}
		else{
		System.out.println("First Name: "+fName);
		System.out.println("Last Name: "+lName);
		System.out.println("gender: "+gender);
		}
	}
}
