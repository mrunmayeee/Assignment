package com.Mrunmayi.Assignment6.Assign62;

import java.util.Scanner;

public class TestBank {

	public static void main(String[] args) {

		float age1,age2;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter age");
		age1 = sc.nextInt();
		Person smith = new Person("Smith", age1);
		System.out.println("Enter age");
		age2 = sc.nextInt();
		Person kathy = new Person("Kathy", age2);
		sc.close();
		if (age1 < 16f) {
		
				try {
					throw new AgeException(age1);
				} catch (AgeException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
		}
		else if(age2 < 16f){
			try {
				throw new AgeException(age2);
			} catch (AgeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
		else {

			// System.out.println(smith);
			Account smithAcc = new Account(2000);
			smithAcc.setAccHolder(smith);
			System.out.println(smithAcc);
			smithAcc.deposit(2000);

			// System.out.println(kathy);
			Account kathyAcc = new Account(3000);
			kathyAcc.setAccHolder(kathy);
			System.out.println(kathyAcc);
			kathyAcc.withdraw(2000);

			System.out.println("Updated balance of Smith: "
					+ smithAcc.getBalance());
			System.out.println("Updated balance of Kathy: "
					+ kathyAcc.getBalance());
		}

	}

}
