package com.Mrunmayi.Assignment6.Assign62;

public class AgeException extends Exception {

	private float age;
	AgeException(float age){
		this.age=age;
	}
	@Override
	public String toString() {
		return age+" Invalid age";
	}
	
	
}
