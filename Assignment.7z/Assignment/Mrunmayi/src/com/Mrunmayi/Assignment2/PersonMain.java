package com.Mrunmayi.Assignment2;

public class PersonMain {

	public static void main(String[] args) {
		
		System.out.println("Person Details");
		System.out.println("---------------------");
		
		Person p = new Person(); //for default constructor
		p.show();
		
		Person p1 = new Person("Neha","Verma",'F'); // for parameterized constructor
		p1.show();

		Person p3 = new Person(); //for getters and setters
		p3.setfName("Mrunmayi");
		p3.setLName("Chamankar");
		p3.setGender('F');
		p3.show();
		
	}

}
