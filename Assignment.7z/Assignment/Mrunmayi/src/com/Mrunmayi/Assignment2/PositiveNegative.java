package com.Mrunmayi.Assignment2;

public class PositiveNegative {

	public static void main(String[] args) {
		
		int num;
		
		num = Integer.parseInt(args[0]);
		
		if(num>0){
			System.out.println(num+" is positive number");
		}
		else if(num<0){
			System.out.println(num+" is negative number");
		}
		else{
			System.out.println(num+" is neither negative nor positive number");
		}

	}

}
