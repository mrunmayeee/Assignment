package com.Mrunmayi.Assignment2;

import java.util.Scanner;

public class TestPerson {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Mobile Number:");
		int mphone= sc.nextInt();
		
		
		/*Persons ps = new Persons(); //for default constructor
		ps.show();*/
		
		Persons ps1 = new Persons("Neha","Verma",'F',mphone); // for parameterized constructor
		ps1.show();
		
		sc.close();

		/*Persons ps3 = new Persons(); //for getters and setters
		ps3.setfName("Mrunmayi");
		ps3.setLName("Chamankar");
		ps3.setGender('F');
		ps3.setPhoneNo(8446469);
		ps3.show();*/

	}

}
