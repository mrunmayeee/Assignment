package com.Mrunmayi.Assignment2;

import java.util.Scanner;

public class EnumPerson {

	public static void main(String[] args) {
		
		Gender gender= null;
		System.out.println("Enter gender:");
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		
		gender = gender.valueOf(str);
		
		
		
		
		
		
		DetPerson dp = new DetPerson("Lisa","D'sa",gender,88891);
		dp.show();
		
		DetPerson dp1 = new DetPerson("Mayur","Patil",gender,88891);
		dp1.show();
		
	}

}
