import java.util.function.*;
public class TestLambda {

	public static void main(String[] args) {


		TestInterface test =(int x) -> (x+10);
		System.out.println(test.fun(5));
	}

}
