package com.cg.eis.JUnit;



import com.cg.eis.bean.Employee;

import junit.framework.TestCase;

public class EmployeeInsuranceSystemTest extends TestCase {

	public void testInsuranceScheme() {
		Employee emp = new Employee(1234,2000,"Mahesh","Manager");
		assertEquals("Salary should not be less than 3000",emp.getInsuranceScheme());
	}

}
