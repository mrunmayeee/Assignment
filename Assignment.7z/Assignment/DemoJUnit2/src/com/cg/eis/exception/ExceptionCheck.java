package com.cg.eis.exception;

public class ExceptionCheck extends Exception {

	String msg;

	public ExceptionCheck(String msg) {
		super(msg);
	}
}
