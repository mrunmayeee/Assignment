package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public interface EmployeeService {

	public void getDetails(Employee emp);
	public String insuranceScheme(Employee emp);
	public void displayDetails(Employee emp);
}
